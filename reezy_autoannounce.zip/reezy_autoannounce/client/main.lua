Citizen.CreateThread(function()
  while true do
    TriggerEvent(cfg.announce, cfg.text)
    Citizen.Wait(cfg.time)
  end
end)
  