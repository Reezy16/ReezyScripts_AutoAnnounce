
-- Made by ReezyScripts#9999

cfg                          = {}

cfg.text = 'Bugs im DC melden: discord.gg/Hj4sM8NS3K' -- Schreibe hier die automatiesierte Nachricht

cfg.time = 900000 -- Alle 15 Minuten wird die Nachricht gesendet (Millisekunden)

cfg.announce = 'd-notification' -- Euer Event Trigger von eurem Announce Script+